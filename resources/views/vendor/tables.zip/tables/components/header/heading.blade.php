<h2 {{ $attributes->class(['filament-tables-header-heading text-xl font-bold tracking-tight']) }}>
    {{ $slot }}
</h2>
