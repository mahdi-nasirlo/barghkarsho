<x-tables::actions.action
    :action="$action"
    :label="$getLabel()"
    component="tables::icon-button"
    class="filament-tables-icon-button-action -my-2"
/>
