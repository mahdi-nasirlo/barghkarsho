<x-filament-support::actions.group
    :actions="$getActions()"
    :dark-mode="config('tables.dark_mode')"
    :color="$getColor()"
    :icon="$getIcon()"
    :label="$getLabel()"
    :tooltip="$getTooltip()"
/>
